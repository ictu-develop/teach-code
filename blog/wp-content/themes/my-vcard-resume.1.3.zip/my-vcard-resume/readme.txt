﻿=== My vCard Resume ===

Contributors: aThemeArt
Requires at least: 4.0
Tested up to: 4.9.5
Stable tag: 1.3
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==

My vCard Resume is a Modern, Minimal & Creative  WordPress theme for online resume, cv, or a personal website. This beautiful online resume template comes with a built-in portfolio type . My vCard Resume is suitable for designer, developer, freelancer, photographer, architects, Artists and many more individual who want to showcase his/her work. It is a high performance template it’s help to load your website fast and it’s fully optimize and clean code help search engine to optimize website. It comes with pre-defined sections for skills, education, work experience, etc. All theme options can be easily set up using live theme customizer. 

It’s 100% responsive that’s why it will work nicely on all smart devices(smart phones, tablet, PCs and desktops). It’s also well documented and clean coded that’s why anyone can change it easily.


== Copyright ==
My vCard Resume WordPress Theme, Copyright (C) 2018 aThemeArt.com
My vCard Resume is distributed under the terms of the GNU GPL

== Installation ==
	
1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Credits ==

Underscores:
Author: 2012-2015 Automattic
Source: http://underscores.me
License: GPLv3 or later](https://www.gnu.org/licenses/gpl-3.0.html)

Bootstrap:
Author: Twitter
Source: http://getbootstrap.com
License: Licensed under the MIT license

Fontawesome :
Author: fontawesome
Source: http://fontawesome.io/
License: [MIT/SIL OFL Licensed](http://fontawesome.io/license/)

Customizer:
Author: https://github.com/justintadlock
Source: https://github.com/justintadlock/trt-customizer-pro
License: GNU GPL

Owl Carousel 2:
Author: David Deutsch
Source: https://github.com/OwlCarousel2/OwlCarousel2
License: [MIT License.]

Magnific Popup:
Author: ChubbyNinja 
Source: https://github.com/dimsemenov/Magnific-Popup
License: MIT License


Tgmpluginactivation:
Source: http://tgmpluginactivation.com/
License: GPL-2.0 or later license.

wp bootstrap navwalker:
Source: https://github.com/wp-bootstrap/wp-bootstrap-navwalker
License: GPL-2.0 or later license.



== Google Fonts ==
Roboto
Source: https://fonts.google.com/specimen/Roboto?selection.family=Roboto
License: Open Font License 

Roboto Condensed
Source: https://fonts.google.com/specimen/Roboto+Condensed
License: Open Font License 

== Image Used ==
https://pixabay.com/en/typing-computer-desk-hoe-office-849806/
https://pixabay.com/en/adult-break-business-caucasian-2449725/
All are Licensed under CC0


== Changelog ==
= 1.2 =
* Plugins recommended  & esc_attr__

= 1.2 =
* Review Team feedback fixed !

= 1.1 =
* Review Team feedback fixed !

= 1.0 =
* Initial release

